% Note: params from
% http://content.cdlib.org/view?docId=kt4k4003mr;NAAN=13030&doc.view=frames
% &chunk.id=d0e448&toc.id=d0e154&brand=calisphere
% Yelloweye Rockfish:
% L_inf = 646 (female) 756 (male) 666 (combined)
% k = .1153 (female) .0890 (male) .1117 (combined)
% t_0 = -0.2 (female) 0 (male) 0 (combined)
% start with female only pop

classdef Population < handle
    
    properties (GetAccess = 'public')
        %main population state vars, with default values
        nAgeClasses = 1; 
        nIndividualsAtAge = zeros(0,1);
        survivalAtAge = ones(0,1);
        fecundityAtAge = zeros(0,1);
        trajectory = zeros(0,1);
        selectivityAtAge = zeros(0,1);
        migrationProbAtAge = zeros(0,1);
    end
    
    properties (GetAccess = 'private')
        lengthAtAge = zeros(0,1); 
        maturityAtAge = zeros(0,1);
        
        %BH recruitment parameters
        steepness = 0;
        sigmaR = 0;
        alpha = 0;
        beta = 0;
        
        %TODO: better understand this param
        eo = 0;
        
        % appropriate param values?
        startPopAtAge = zeros(0, 1);
        virginRecruitment = 1;
        ageZeroStartPop = 1;

    end
    
    methods
     function pop = Population(speciesParams, populationParams)
          
          % Set up age-specific parameter matrices with proper number of
          % age classes
          pop.nAgeClasses = speciesParams{1,1};
          pop.lengthAtAge = zeros(pop.nAgeClasses,1);
          pop.maturityAtAge = zeros(pop.nAgeClasses,1);
          pop.fecundityAtAge = zeros(pop.nAgeClasses, 1); 
          pop.survivalAtAge = ones(pop.nAgeClasses, 1);
          pop.startPopAtAge = zeros(pop.nAgeClasses, 1);
          
          % migration params
          pop.migrationProbAtAge = speciesParams{12,1};
          
          % Set up natural mortality / survival
          survivalRate = speciesParams{2,1};
          pop.survivalAtAge = pop.survivalAtAge .* survivalRate;
          
          % Calculate initial age structure
          pop.ageZeroStartPop = populationParams(1);
          pop.startPopAtAge(1) = pop.ageZeroStartPop;

          % Calculate start population, length, and maturity by age class
          
          % extract VB growth params
          lMax = speciesParams{3,1};
          ageAtLengthZero = speciesParams{4,1};
          kVB = speciesParams{5,1};
          
          % extract maturity curve params
          b0Mat = speciesParams{6,1};
          b1Mat = speciesParams{7,1};
          
          for ageClass=1:pop.nAgeClasses
             %set up initial age structure
             if(ageClass > 1)
                pop.startPopAtAge(ageClass) = pop.startPopAtAge(ageClass-1) * pop.survivalAtAge(ageClass-1);
             end
             
             % Length structure based on VB growth
             pop.lengthAtAge(ageClass) = lMax * (1 - exp(-1 * kVB * (ageClass - (ageAtLengthZero)))); 
             
             % Logistic Maturity curve
             pop.maturityAtAge(ageClass) = exp(b0Mat + b1Mat*ageClass) / (1 + exp(b0Mat + b1Mat*ageClass));
          end
          
          pop.nIndividualsAtAge = pop.startPopAtAge;
          pop.trajectory = pop.nIndividualsAtAge;  
          
          % Beverton-Holt recruitment params
          pop.virginRecruitment = populationParams(2);
          pop.fecundityAtAge = speciesParams{8,1};
          pop.steepness = speciesParams{9,1};
          pop.sigmaR = speciesParams{10,1};
          pop.eo = sum(pop.fecundityAtAge .* pop.maturityAtAge .* pop.startPopAtAge);
          pop.alpha = pop.eo * (1 - pop.steepness) / (4 * pop.steepness * pop.virginRecruitment);
          pop.beta = (5 * pop.steepness - 1) / (4 * pop.steepness * pop.virginRecruitment);
 
          % Harvest Params
          pop.selectivityAtAge = speciesParams{11,1};          
          
     end
     
     function setPopulationAtAge(pop, newPopAtAge)
        pop.nIndividualsAtAge = newPopAtAge;
        pop.trajectory(:, size(pop.trajectory, 2)) = pop.nIndividualsAtAge;
     end
     
     function grow(pop, randNum)

         nMaturesAtAge = pop.nIndividualsAtAge .* pop.maturityAtAge;
         nEggs = sum(nMaturesAtAge .* pop.fecundityAtAge);
         
         %TODO: V-B recruitment calculation and parameterization 
         nRecruits = nEggs / (pop.alpha + pop.beta * nEggs) * exp(pop.sigmaR * randNum - pop.sigmaR^2) / 2;
         

         survivors = pop.survivalAtAge .* pop.nIndividualsAtAge;
         for ageClass = 2:pop.nAgeClasses
            pop.nIndividualsAtAge(ageClass) = survivors(ageClass -1); 
         end
         pop.nIndividualsAtAge(1) = nRecruits;
         pop.trajectory = [pop.trajectory pop.nIndividualsAtAge];
         
     end

     function [indCaughtAtAge] = harvest(pop, effort)
        
         %find out how many were caught
         indCaughtAtAge = pop.nIndividualsAtAge .* pop.selectivityAtAge * effort;
         
         %adjust population and trajectory
         pop.nIndividualsAtAge = pop.nIndividualsAtAge - indCaughtAtAge;
         pop.trajectory(:, size(pop.trajectory, 2)) = pop.nIndividualsAtAge;
         
     end
     
     function totalPop = getTotalPopulation(pop)
        totalPop = sum(pop.nIndividualsAtAge);
     end
     
     function totalTrajectory = getTotalPopulationTrajectory(pop)
         totalTrajectory = sum(pop.trajectory);
     end
    end
end