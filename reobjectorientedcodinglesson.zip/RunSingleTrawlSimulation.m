function [simulationResults] = RunSingleTrawlSimulation(params, randomSequence)
    
    %unpack relevant parameters
    nTimesteps = params{2,1};
    nPatches = params{3,1};
    harvestParams = params{4,1};
    speciesParams = params{5,1};
    populationParams = params{6,1};
    migrationParams = params{7,1};
    
    % initialize populations in each patch
    populations = Population.empty(nPatches, 0);
    for p=1:nPatches
       populations(p) = Population(speciesParams, populationParams(:,p)); 
    end
    
    %Pull out effort by patch from harvest params
    effortByPatch = harvestParams(1,:);

    %precalc migration matrix
    %get overall matrix of inter-patch migration
    patchMigrationMatrix = migrationParams;
    nAgeClasses = speciesParams{1,1};
    migMat = zeros(nPatches*nAgeClasses, nPatches*nAgeClasses);
    for p=1:nPatches
        for otherP=1:nPatches
            migSubmat = diag(patchMigrationMatrix(p, otherP) .* populations(p).migrationProbAtAge);
            if(p==otherP)
                %Note: the patch migration matrix allows for migrating
                %individuals to stay within a patch, so we technically don't want to treat individuals
                %that stay in the patch any differently than those that migrate. But having an
                %age-specific "probability of migration" allows for easier
                %parameterization and age-specific migration parameters
                %that are orthogonal to inter-patch migration
                %probabilities. This calculation just adds those that
                %"don't migrate" and those that "migrate but end up in the
                %same place" together for the appropriate block of the
                %overall migration matrix. Note that this will NOT work if
                %the migration probabilities across age and space are not
                %independent (e.g. if a 2 year old will migrate against currents
                %while a larvae won't).
                probExemptFromMigration = diag(ones(nAgeClasses,1) - populations(p).migrationProbAtAge);
                migSubmat = migSubmat + probExemptFromMigration;
            end

            startRow = (p-1)*nAgeClasses + 1;
            endRow = p*nAgeClasses;
            startCol = (otherP-1)*nAgeClasses + 1;
            endCol = otherP*nAgeClasses;
            migMat(startRow:endRow,startCol:endCol) = migSubmat;
        end
    end    
    
    
    %Run simulation
    for t=1:nTimesteps
        
        % update patch populations for growth + harvest
        for p=1:nPatches
            populations(p).grow(randomSequence(t)); % grow
            populations(p).harvest(effortByPatch(p)); % harvest
            
        end

        %Update patch populations for migration

        curPops = zeros(0, 1);
        for p=1:nPatches
        	curPops = [curPops; populations(p).nIndividualsAtAge]; 
        end      
        
        newPops = migMat * curPops;
        for p=1:nPatches
            startIndex = (p-1)* nAgeClasses + 1;
            endIndex = (p)* nAgeClasses;
            populations(p).setPopulationAtAge(newPops(startIndex:endIndex,1));
        end           
        
        
    end 
    
    trajectories = zeros(nPatches, nTimesteps+1);
    for p=1:nPatches
       disp('end population');
       disp(populations(p).getTotalPopulation()); 
       patchPopTrajectory = populations(p).getTotalPopulationTrajectory();
       trajectories(p,:) = patchPopTrajectory;
    end
    
    
    simulationResults = trajectories;

end